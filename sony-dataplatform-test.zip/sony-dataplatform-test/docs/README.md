# AWS + Databricks Assessment

This submission includes secure AWS infrastructure as code, Databricks admin/job artifacts, a FinOps mini-analysis, and the ETL aggregate requested from the baseball datasets.

## What Is Included
- `infra/`: Terraform for S3 raw/curated buckets, KMS, IAM roles, AWS Budget alert, AWS Config S3 public-access guardrail, and CI skeleton.
- `pipelines/`: Databricks cluster policy, pool config, workflow job JSON, ingestion script for all 5 CSV files, and access-control notes.
- `finops/`: Cost analysis script plus generated report and aggregates.
- `sql/`: Team-year efficiency SQL, local validator, and sample output.

## Key Design Choices
- Security: TLS-only and SSE-KMS on S3, mandatory tags, least-privilege Databricks job role, S3 public-access checks via AWS Config.
- Cost: lifecycle on raw data, budget alert at 80%, cluster policy limits, pool usage, and Spot-with-fallback.
- Reliability: idempotent ingestion (overwrite + dedupe), basic data quality checks, deterministic SQL output ordering.

## How To Run
1. `terraform -chdir=infra init`
2. `terraform -chdir=infra validate`
3. `terraform -chdir=infra plan -out=tfplan`
4. `python finops/analyze_costs.py`
5. `python sql/run_team_efficiency_local.py`

## Before Zipping
Delete local-only caches and environment folders to reduce zip size.

Safe to delete:
- `.venv/`
- `infra/.terraform/`
- `pipelines/__pycache__/`
- `sql/__pycache__/`
- `finops/__pycache__/`

PowerShell cleanup commands (run from repo root):
```powershell
Remove-Item -Recurse -Force .venv, infra/.terraform, pipelines/__pycache__, sql/__pycache__, finops/__pycache__ -ErrorAction SilentlyContinue
```

Create zip (PowerShell):
```powershell
Compress-Archive -Path aws_costs.csv, Batting.csv, CollegePlaying.csv, People.csv, Salaries.csv, Schools.csv, infra, pipelines, sql, finops, README.md -DestinationPath sony-dataplatform-submission.zip -Force
```

## Main Deliverables
- Infra: `infra/main.tf`, `infra/variables.tf`, `infra/outputs.tf`, `infra/tfplan`
- Databricks: `pipelines/cluster_policy.json`, `pipelines/pool_config.json`, `pipelines/job_definition.json`, `pipelines/ingest_baseball_to_delta.py`
- FinOps: `finops/finops_report.md`, `finops/top_service_costs.csv`, `finops/top_usage_costs.csv`, `finops/tag_coverage.csv`
- ETL: `sql/team_efficiency.sql`, `sql/team_efficiency_sample.csv`

## Notes
- Terraform and local Python validations were run successfully in this workspace.
- For a production version, CI/CD IAM can be narrowed further with explicit ARNs.
