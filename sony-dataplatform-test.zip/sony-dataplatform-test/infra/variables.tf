variable "aws_region" {
  type    = string
  default = "us-east-1"
}

variable "project_name" {
  type    = string
  default = "sony-dataplatform"
}

variable "environment" {
  type    = string
  default = "dev"
}

variable "owner" {
  type    = string
  default = "data-platform"
}

variable "cost_center" {
  type    = string
  default = "DP1001"
}

variable "raw_bucket_name" {
  type    = string
  default = "sony-dp-raw-dev-001"
}

variable "curated_bucket_name" {
  type    = string
  default = "sony-dp-curated-dev-001"
}

variable "raw_transition_days" {
  type    = number
  default = 30
}

variable "raw_expire_days" {
  type    = number
  default = 365
}

variable "monthly_budget_limit_usd" {
  type    = string
  default = "500"
}

variable "budget_alert_email" {
  type    = string
  default = "alerts@example.com"
}

variable "cicd_assume_role_principal_arn" {
  type    = string
  default = "arn:aws:iam::111111111111:role/github-actions-oidc"
}

variable "enable_offline_plan" {
  type    = bool
  default = true
}

variable "extra_tags" {
  type    = map(string)
  default = {}
}
