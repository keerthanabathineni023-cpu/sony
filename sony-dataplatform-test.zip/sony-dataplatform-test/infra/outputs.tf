output "raw_bucket_name" {
  value = aws_s3_bucket.raw.bucket
}

output "curated_bucket_name" {
  value = aws_s3_bucket.curated.bucket
}

output "kms_key_arn" {
  value = aws_kms_key.s3.arn
}

output "databricks_instance_profile_name" {
  value = aws_iam_instance_profile.databricks_job_profile.name
}

output "cicd_role_arn" {
  value = aws_iam_role.cicd_role.arn
}
