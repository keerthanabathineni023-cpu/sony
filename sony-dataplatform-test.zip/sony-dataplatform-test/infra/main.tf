provider "aws" {
  region                      = var.aws_region
  skip_credentials_validation = var.enable_offline_plan
  skip_metadata_api_check     = var.enable_offline_plan
  skip_requesting_account_id  = var.enable_offline_plan
}

locals {
  tags = merge({
    App        = var.project_name
    Env        = var.environment
    Owner      = var.owner
    CostCenter = var.cost_center
  }, var.extra_tags)
}

resource "aws_kms_key" "s3" {
  description             = "CMK for S3 encryption for ${var.project_name}-${var.environment}"
  enable_key_rotation     = true
  deletion_window_in_days = 7
  tags                    = local.tags
}

resource "aws_kms_alias" "s3" {
  name          = "alias/${var.project_name}-${var.environment}-s3"
  target_key_id = aws_kms_key.s3.key_id
}

resource "aws_s3_bucket" "raw" {
  bucket = var.raw_bucket_name
  tags   = local.tags
}

resource "aws_s3_bucket" "curated" {
  bucket = var.curated_bucket_name
  tags   = local.tags
}

resource "aws_s3_bucket_public_access_block" "raw" {
  bucket                  = aws_s3_bucket.raw.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_public_access_block" "curated" {
  bucket                  = aws_s3_bucket.curated.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_server_side_encryption_configuration" "raw" {
  bucket = aws_s3_bucket.raw.id

  rule {
    apply_server_side_encryption_by_default {
      kms_master_key_id = aws_kms_key.s3.arn
      sse_algorithm     = "aws:kms"
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "curated" {
  bucket = aws_s3_bucket.curated.id

  rule {
    apply_server_side_encryption_by_default {
      kms_master_key_id = aws_kms_key.s3.arn
      sse_algorithm     = "aws:kms"
    }
    bucket_key_enabled = true
  }
}

resource "aws_s3_bucket_versioning" "curated" {
  bucket = aws_s3_bucket.curated.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "raw" {
  bucket = aws_s3_bucket.raw.id

  rule {
    id     = "raw-retention"
    status = "Enabled"

    filter {}

    transition {
      days          = var.raw_transition_days
      storage_class = "STANDARD_IA"
    }

    expiration {
      days = var.raw_expire_days
    }
  }
}

data "aws_iam_policy_document" "s3_deny_insecure_raw" {
  statement {
    sid    = "DenyInsecureTransport"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions   = ["s3:*"]
    resources = [aws_s3_bucket.raw.arn, "${aws_s3_bucket.raw.arn}/*"]

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }

  statement {
    sid    = "DenyIncorrectEncryptionHeader"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions   = ["s3:PutObject"]
    resources = ["${aws_s3_bucket.raw.arn}/*"]

    condition {
      test     = "StringNotEquals"
      variable = "s3:x-amz-server-side-encryption"
      values   = ["aws:kms"]
    }
  }
}

data "aws_iam_policy_document" "s3_deny_insecure_curated" {
  statement {
    sid    = "DenyInsecureTransport"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions   = ["s3:*"]
    resources = [aws_s3_bucket.curated.arn, "${aws_s3_bucket.curated.arn}/*"]

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }

  statement {
    sid    = "DenyIncorrectEncryptionHeader"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions   = ["s3:PutObject"]
    resources = ["${aws_s3_bucket.curated.arn}/*"]

    condition {
      test     = "StringNotEquals"
      variable = "s3:x-amz-server-side-encryption"
      values   = ["aws:kms"]
    }
  }
}

resource "aws_s3_bucket_policy" "raw" {
  bucket = aws_s3_bucket.raw.id
  policy = data.aws_iam_policy_document.s3_deny_insecure_raw.json
}

resource "aws_s3_bucket_policy" "curated" {
  bucket = aws_s3_bucket.curated.id
  policy = data.aws_iam_policy_document.s3_deny_insecure_curated.json
}

data "aws_iam_policy_document" "databricks_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ec2.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "databricks_job_role" {
  name               = "${var.project_name}-${var.environment}-databricks-job-role"
  assume_role_policy = data.aws_iam_policy_document.databricks_assume_role.json
  tags               = local.tags
}

data "aws_iam_policy_document" "databricks_job_permissions" {
  statement {
    effect = "Allow"
    actions = [
      "s3:ListBucket"
    ]
    resources = [
      aws_s3_bucket.raw.arn,
      aws_s3_bucket.curated.arn
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject"
    ]
    resources = [
      "${aws_s3_bucket.raw.arn}/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "s3:PutObject",
      "s3:DeleteObject",
      "s3:GetObject"
    ]
    resources = [
      "${aws_s3_bucket.curated.arn}/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "kms:Decrypt",
      "kms:Encrypt",
      "kms:GenerateDataKey"
    ]
    resources = [aws_kms_key.s3.arn]
  }
}

resource "aws_iam_policy" "databricks_job_policy" {
  name   = "${var.project_name}-${var.environment}-databricks-job-s3-policy"
  policy = data.aws_iam_policy_document.databricks_job_permissions.json
  tags   = local.tags
}

resource "aws_iam_role_policy_attachment" "databricks_job_attach" {
  role       = aws_iam_role.databricks_job_role.name
  policy_arn = aws_iam_policy.databricks_job_policy.arn
}

resource "aws_iam_instance_profile" "databricks_job_profile" {
  name = "${var.project_name}-${var.environment}-databricks-job-profile"
  role = aws_iam_role.databricks_job_role.name
  tags = local.tags
}

data "aws_iam_policy_document" "cicd_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "AWS"
      identifiers = [var.cicd_assume_role_principal_arn]
    }
  }
}

resource "aws_iam_role" "cicd_role" {
  name               = "${var.project_name}-${var.environment}-terraform-cicd-role"
  assume_role_policy = data.aws_iam_policy_document.cicd_assume_role.json
  tags               = local.tags
}

data "aws_iam_policy_document" "cicd_permissions" {
  statement {
    effect = "Allow"
    actions = [
      "s3:CreateBucket",
      "s3:PutBucketPolicy",
      "s3:PutBucketEncryption",
      "s3:PutBucketVersioning",
      "s3:PutBucketPublicAccessBlock",
      "s3:PutLifecycleConfiguration",
      "s3:PutBucketTagging",
      "s3:DeleteBucket",
      "s3:GetBucketLocation",
      "s3:ListBucket",
      "s3:GetBucketPolicy"
    ]
    resources = [
      aws_s3_bucket.raw.arn,
      aws_s3_bucket.curated.arn,
      "${aws_s3_bucket.raw.arn}/*",
      "${aws_s3_bucket.curated.arn}/*"
    ]
  }

  statement {
    effect = "Allow"
    actions = [
      "kms:CreateKey",
      "kms:CreateAlias",
      "kms:TagResource",
      "kms:ScheduleKeyDeletion",
      "kms:DescribeKey",
      "kms:EnableKeyRotation",
      "kms:PutKeyPolicy"
    ]
    resources = ["*"]
  }

  statement {
    effect = "Allow"
    actions = [
      "iam:CreateRole",
      "iam:DeleteRole",
      "iam:AttachRolePolicy",
      "iam:DetachRolePolicy",
      "iam:CreatePolicy",
      "iam:DeletePolicy",
      "iam:PassRole",
      "iam:CreateInstanceProfile",
      "iam:AddRoleToInstanceProfile",
      "iam:DeleteInstanceProfile",
      "iam:TagRole",
      "iam:TagPolicy"
    ]
    resources = ["*"]
  }

  statement {
    effect = "Allow"
    actions = [
      "budgets:CreateBudget",
      "budgets:UpdateBudget",
      "budgets:DeleteBudget",
      "budgets:DescribeBudget",
      "budgets:DescribeNotificationsForBudget"
    ]
    resources = ["*"]
  }

  statement {
    effect = "Allow"
    actions = [
      "config:PutConfigRule",
      "config:DeleteConfigRule",
      "config:PutConfigurationRecorder",
      "config:PutDeliveryChannel",
      "config:StartConfigurationRecorder",
      "config:DeleteConfigurationRecorder",
      "config:DeleteDeliveryChannel"
    ]
    resources = ["*"]
  }
}

resource "aws_iam_policy" "cicd_policy" {
  name   = "${var.project_name}-${var.environment}-terraform-cicd-policy"
  policy = data.aws_iam_policy_document.cicd_permissions.json
  tags   = local.tags
}

resource "aws_iam_role_policy_attachment" "cicd_attach" {
  role       = aws_iam_role.cicd_role.name
  policy_arn = aws_iam_policy.cicd_policy.arn
}

resource "aws_budgets_budget" "monthly" {
  name         = "${var.project_name}-${var.environment}-monthly-budget"
  budget_type  = "COST"
  limit_amount = var.monthly_budget_limit_usd
  limit_unit   = "USD"
  time_unit    = "MONTHLY"

  notification {
    comparison_operator        = "GREATER_THAN"
    threshold                  = 80
    threshold_type             = "PERCENTAGE"
    notification_type          = "ACTUAL"
    subscriber_email_addresses = [var.budget_alert_email]
  }

  cost_filter {
    name   = "TagKeyValue"
    values = [format("user:App$%s", var.project_name)]
  }

  tags = local.tags
}

resource "aws_s3_bucket" "config" {
  bucket = "${var.project_name}-${var.environment}-config-recorder-001"
  tags   = local.tags
}

data "aws_iam_policy_document" "config_assume_role" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["config.amazonaws.com"]
    }
  }
}

resource "aws_iam_role" "config_role" {
  name               = "${var.project_name}-${var.environment}-aws-config-role"
  assume_role_policy = data.aws_iam_policy_document.config_assume_role.json
  tags               = local.tags
}

resource "aws_iam_role_policy_attachment" "config_managed_attach" {
  role       = aws_iam_role.config_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWS_ConfigRole"
}

resource "aws_config_configuration_recorder" "main" {
  name     = "${var.project_name}-${var.environment}-config-recorder"
  role_arn = aws_iam_role.config_role.arn

  recording_group {
    all_supported                 = true
    include_global_resource_types = true
  }
}

resource "aws_config_delivery_channel" "main" {
  name           = "${var.project_name}-${var.environment}-config-channel"
  s3_bucket_name = aws_s3_bucket.config.bucket

  depends_on = [aws_config_configuration_recorder.main]
}

resource "aws_config_configuration_recorder_status" "main" {
  name       = aws_config_configuration_recorder.main.name
  is_enabled = true

  depends_on = [aws_config_delivery_channel.main]
}

resource "aws_config_config_rule" "s3_not_public_read" {
  name = "${var.project_name}-${var.environment}-s3-public-read-prohibited"

  source {
    owner             = "AWS"
    source_identifier = "S3_BUCKET_PUBLIC_READ_PROHIBITED"
  }

  depends_on = [aws_config_configuration_recorder_status.main]
}
