WITH batting_team_year AS (
  SELECT
    teamID,
    yearID,
    SUM(COALESCE(CAST(AB AS DOUBLE), 0)) AS AB,
    SUM(COALESCE(CAST(H AS DOUBLE), 0)) AS H,
    SUM(COALESCE(CAST(HR AS DOUBLE), 0)) AS HR,
    SUM(COALESCE(CAST(`2B` AS DOUBLE), 0)) AS doubles,
    SUM(COALESCE(CAST(`3B` AS DOUBLE), 0)) AS triples
  FROM batting
  GROUP BY teamID, yearID
),
salary_team_year AS (
  SELECT
    teamID,
    yearID,
    SUM(COALESCE(CAST(salary AS DOUBLE), 0)) AS total_payroll
  FROM salaries
  GROUP BY teamID, yearID
)
SELECT
  b.teamID,
  b.yearID,
  s.total_payroll,
  b.AB,
  b.HR,
  CASE
    WHEN b.AB > 0 THEN b.H / b.AB
    ELSE 0
  END AS BA,
  CASE
    WHEN b.AB > 0 THEN ((b.H - b.doubles - b.triples - b.HR) + (2 * b.doubles) + (3 * b.triples) + (4 * b.HR)) / b.AB
    ELSE 0
  END AS SLG,
  CASE
    WHEN s.total_payroll IS NULL OR s.total_payroll = 0 THEN NULL
    ELSE b.HR / (s.total_payroll / 1000000.0)
  END AS HR_per_Million
FROM batting_team_year b
LEFT JOIN salary_team_year s
  ON b.teamID = s.teamID
  AND b.yearID = s.yearID
ORDER BY b.yearID, b.teamID;
