import csv
from collections import defaultdict
from pathlib import Path


def to_float(value):
    if value is None or value == "":
        return 0.0
    return float(value)


def build_team_efficiency(base_path):
    batting_path = Path(base_path) / "Batting.csv"
    salaries_path = Path(base_path) / "Salaries.csv"

    batting_agg = defaultdict(lambda: {"AB": 0.0, "H": 0.0, "HR": 0.0, "2B": 0.0, "3B": 0.0})
    salaries_agg = defaultdict(float)

    with batting_path.open(newline="", encoding="utf-8-sig") as f:
      reader = csv.DictReader(f)
      for row in reader:
        team = row["teamID"]
        year = int(row["yearID"])
        key = (team, year)
        batting_agg[key]["AB"] += to_float(row["AB"])
        batting_agg[key]["H"] += to_float(row["H"])
        batting_agg[key]["HR"] += to_float(row["HR"])
        batting_agg[key]["2B"] += to_float(row["2B"])
        batting_agg[key]["3B"] += to_float(row["3B"])

    with salaries_path.open(newline="", encoding="utf-8-sig") as f:
      reader = csv.DictReader(f)
      for row in reader:
        team = row["teamID"]
        year = int(row["yearID"])
        salaries_agg[(team, year)] += to_float(row["salary"])

    rows = []
    for team, year in sorted(batting_agg.keys(), key=lambda x: (x[1], x[0])):
        b = batting_agg[(team, year)]
        payroll = salaries_agg.get((team, year), None)
        ab = b["AB"]
        h = b["H"]
        hr = b["HR"]
        doubles = b["2B"]
        triples = b["3B"]
        ba = (h / ab) if ab > 0 else 0.0
        slg = (((h - doubles - triples - hr) + 2 * doubles + 3 * triples + 4 * hr) / ab) if ab > 0 else 0.0
        hr_per_million = (hr / (payroll / 1000000.0)) if payroll and payroll > 0 else None
        rows.append({
            "teamID": team,
            "yearID": year,
            "total_payroll": payroll,
            "AB": ab,
            "HR": hr,
            "BA": ba,
            "SLG": slg,
            "HR_per_Million": hr_per_million
        })
    return rows


def write_sample(rows, output_file, limit=10):
    headers = ["teamID", "yearID", "total_payroll", "AB", "HR", "BA", "SLG", "HR_per_Million"]
    with Path(output_file).open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=headers)
        writer.writeheader()
        for row in rows[:limit]:
            writer.writerow(row)


def run_checks(rows):
    seen = set()
    for row in rows:
        key = (row["teamID"], row["yearID"])
        if key in seen:
            raise ValueError("duplicate teamID-yearID row detected")
        seen.add(key)


if __name__ == "__main__":
    base = Path(__file__).resolve().parents[1]
    result = build_team_efficiency(base)
    run_checks(result)
    write_sample(result, Path(__file__).resolve().parent / "team_efficiency_sample.csv", limit=10)
    print(f"rows={len(result)}")
