# FinOps Mini Case

Total analyzed cost: $1479.20

## Top Cost Drivers by Service
- AmazonEC2: $1085.00 (73.35%)
- EC2-Other: $216.30 (14.62%)
- AmazonS3: $144.45 (9.77%)
- AmazonCloudWatch: $26.60 (1.8%)
- AWSLambda: $4.75 (0.32%)

## Top Cost Drivers by Usage Type
- BoxUsage:m5.large: $990.00 (66.93%)
- EBS:VolumeUsage.gp3: $193.90 (13.11%)
- TimedStorage-ByteHrs: $124.05 (8.39%)
- SpotUsage:c5.large: $95.00 (6.42%)
- EBS:VolumeIOPS.gp3: $22.40 (1.51%)

## Tag Coverage
- App: 16/16 rows (100.0%)
- Env: 16/16 rows (100.0%)
- Owner: 12/16 rows (75.0%)
- CostCenter: 14/16 rows (87.5%)

## Recommended Savings Actions
- Enforce Spot-backed Databricks pools and worker caps for batch jobs; estimated savings: $289.15/month
- Apply EC2 Savings Plans for steady compute usage baseline; estimated savings: $147.92/month
- Tighten S3 lifecycle for raw data and expire stale files; estimated savings: $73.96/month

## Implemented Controls in Code
- Databricks cluster policy and pool config to restrict expensive shapes, force pools, limit workers, force auto-termination
- Terraform raw bucket lifecycle and AWS budget alert at 80% threshold with tag filter