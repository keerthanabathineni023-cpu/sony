import csv
from collections import defaultdict
from pathlib import Path


def to_float(x):
    if x is None or x == "":
        return 0.0
    return float(x)


def pct(n, d):
    if d == 0:
        return 0.0
    return round((n / d) * 100.0, 2)


def write_csv(path, headers, rows):
    with Path(path).open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        writer.writerows(rows)


def main():
    repo_root = Path(__file__).resolve().parents[1]
    input_file = repo_root / "aws_costs.csv"
    out_dir = Path(__file__).resolve().parent

    service_cost = defaultdict(float)
    usage_cost = defaultdict(float)
    tag_non_empty = defaultdict(int)
    row_count = 0
    total_cost = 0.0

    with input_file.open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row_count += 1
            amount = to_float(row.get("amount"))
            total_cost += amount
            service_cost[row.get("service", "UNKNOWN")] += amount
            usage_cost[row.get("usage_type", "UNKNOWN")] += amount
            for tag in ["App", "Env", "Owner", "CostCenter"]:
                if row.get(tag) not in (None, ""):
                    tag_non_empty[tag] += 1

    top_services = sorted(service_cost.items(), key=lambda x: x[1], reverse=True)
    top_usage = sorted(usage_cost.items(), key=lambda x: x[1], reverse=True)

    top_service_rows = [[s, round(v, 2), pct(v, total_cost)] for s, v in top_services]
    top_usage_rows = [[u, round(v, 2), pct(v, total_cost)] for u, v in top_usage]
    tag_rows = [[t, tag_non_empty[t], row_count, pct(tag_non_empty[t], row_count)] for t in ["App", "Env", "Owner", "CostCenter"]]

    write_csv(out_dir / "top_service_costs.csv", ["service", "cost_usd", "pct_total"], top_service_rows)
    write_csv(out_dir / "top_usage_costs.csv", ["usage_type", "cost_usd", "pct_total"], top_usage_rows)
    write_csv(out_dir / "tag_coverage.csv", ["tag", "non_empty_rows", "total_rows", "coverage_pct"], tag_rows)

    top3_service = top_services[:3]
    baseline = sum(v for _, v in top3_service)
    est_save_1 = round(baseline * 0.2, 2)
    est_save_2 = round(total_cost * 0.1, 2)
    est_save_3 = round(total_cost * 0.05, 2)

    report = []
    report.append("# FinOps Mini Case")
    report.append("")
    report.append(f"Total analyzed cost: ${total_cost:.2f}")
    report.append("")
    report.append("## Top Cost Drivers by Service")
    for service, value in top_services[:5]:
        report.append(f"- {service}: ${value:.2f} ({pct(value, total_cost)}%)")
    report.append("")
    report.append("## Top Cost Drivers by Usage Type")
    for usage, value in top_usage[:5]:
        report.append(f"- {usage}: ${value:.2f} ({pct(value, total_cost)}%)")
    report.append("")
    report.append("## Tag Coverage")
    for tag, non_empty, total, p in tag_rows:
        report.append(f"- {tag}: {non_empty}/{total} rows ({p}%)")
    report.append("")
    report.append("## Recommended Savings Actions")
    report.append(f"- Enforce Spot-backed Databricks pools and worker caps for batch jobs; estimated savings: ${est_save_1:.2f}/month")
    report.append(f"- Apply EC2 Savings Plans for steady compute usage baseline; estimated savings: ${est_save_2:.2f}/month")
    report.append(f"- Tighten S3 lifecycle for raw data and expire stale files; estimated savings: ${est_save_3:.2f}/month")
    report.append("")
    report.append("## Implemented Controls in Code")
    report.append("- Databricks cluster policy and pool config to restrict expensive shapes, force pools, limit workers, force auto-termination")
    report.append("- Terraform raw bucket lifecycle and AWS budget alert at 80% threshold with tag filter")

    (out_dir / "finops_report.md").write_text("\n".join(report), encoding="utf-8")
    print(f"total_cost={total_cost:.2f}")


if __name__ == "__main__":
    main()
