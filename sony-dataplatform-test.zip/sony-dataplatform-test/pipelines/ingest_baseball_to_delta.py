from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T


def ensure_columns(df, required):
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"missing required columns: {missing}")


def validate_year_range(df, col_name):
    bad = df.filter((F.col(col_name).isNotNull()) & ((F.col(col_name) < 1850) | (F.col(col_name) > 2100))).limit(1).count()
    if bad > 0:
        raise ValueError(f"invalid {col_name} range")


def validate_not_null(df, keys):
    condition = None
    for k in keys:
        c = F.col(k).isNull()
        condition = c if condition is None else (condition | c)
    bad = df.filter(condition).limit(1).count()
    if bad > 0:
        raise ValueError(f"null key detected in {keys}")


def normalize_numeric(df, numeric_columns):
    out = df
    for c in numeric_columns:
        out = out.withColumn(c, F.col(c).cast("double"))
    return out


def load_and_write(spark, source_path, table_name, target_path, keys, numeric_columns, partition_cols=None):
    df = spark.read.option("header", "true").csv(source_path)
    ensure_columns(df, keys + numeric_columns)
    df = normalize_numeric(df, numeric_columns)
    for k in keys:
        df = df.withColumn(k, F.trim(F.col(k)))
    if "yearID" in df.columns:
        df = df.withColumn("yearID", F.col("yearID").cast(T.IntegerType()))
        validate_year_range(df, "yearID")
    validate_not_null(df, keys)
    df = df.dropDuplicates()
    writer = df.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
    if partition_cols:
        writer = writer.partitionBy(*partition_cols)
    writer.save(target_path)
    spark.sql(f"CREATE TABLE IF NOT EXISTS baseball_curated.{table_name} USING DELTA LOCATION '{target_path}'")


def main(landing_path, curated_path):
    spark = (
        SparkSession.builder.appName("ingest-baseball-csv")
        .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
        .getOrCreate()
    )
    spark.sql("CREATE DATABASE IF NOT EXISTS baseball_curated")

    load_and_write(
        spark=spark,
        source_path=f"{landing_path}/Batting.csv",
        table_name="batting",
        target_path=f"{curated_path}/batting",
        keys=["playerID", "teamID", "yearID", "stint"],
        numeric_columns=["AB", "H", "2B", "3B", "HR"],
        partition_cols=["yearID"]
    )

    load_and_write(
        spark=spark,
        source_path=f"{landing_path}/Salaries.csv",
        table_name="salaries",
        target_path=f"{curated_path}/salaries",
        keys=["playerID", "teamID", "yearID"],
        numeric_columns=["salary"],
        partition_cols=["yearID"]
    )

    load_and_write(
        spark=spark,
        source_path=f"{landing_path}/People.csv",
        table_name="people",
        target_path=f"{curated_path}/people",
        keys=["playerID"],
        numeric_columns=["birthYear", "deathYear", "height", "weight"]
    )

    load_and_write(
        spark=spark,
        source_path=f"{landing_path}/Schools.csv",
        table_name="schools",
        target_path=f"{curated_path}/schools",
        keys=["schoolID"],
        numeric_columns=[]
    )

    load_and_write(
        spark=spark,
        source_path=f"{landing_path}/CollegePlaying.csv",
        table_name="college_playing",
        target_path=f"{curated_path}/college_playing",
        keys=["playerID", "schoolID", "yearID"],
        numeric_columns=[]
    )

    spark.stop()


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--landing_path", required=True)
    parser.add_argument("--curated_path", required=True)
    args = parser.parse_args()
    main(args.landing_path, args.curated_path)
