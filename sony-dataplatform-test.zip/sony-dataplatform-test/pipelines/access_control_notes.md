# Access Control Notes

## Unity Catalog Structure
- Catalog `raw` for external tables mapped to landing S3 paths.
- Catalog `curated` for quality-assured Delta tables and serving views.
- Schemas by domain: `baseball_ingest`, `baseball_marts`, `ops_audit`.
- Grants: engineers get read on `raw`, write on `curated.baseball_ingest`, analysts read on `curated.baseball_marts`.

## Secrets and Identity
- Prefer AWS instance profile on job clusters for S3 + KMS access.
- Store webhook tokens and external API credentials in Databricks Secret Scopes.
- Use UC storage credentials and external locations for governed data path access.
- Keep PAT usage out of jobs and use service principals for CI/CD automation.
